// var buttonCreate = document.createElement('button');
// buttonCreate.innerHTML = "0";
// buttonCreate.id = "btn";
// document.body.appendChild(buttonCreate);
// btn.onclick = function(){
//     btn.innerHTML++;
// }
var btn = document.createElement("Button");

btn.innerHTML = "0";
btn.id = "btn";
document.body.appendChild(btn);

btn.onclick = function() {
    btn.innerHTML++;
}